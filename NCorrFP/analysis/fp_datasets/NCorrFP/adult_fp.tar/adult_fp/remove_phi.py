import os


def rename_csv_files():
    # Get the list of all files in the current directory
    files = [f for f in os.listdir('.') if os.path.isfile(f)]

    for file in files:
        # Check if the file is a .csv file
        if file.endswith('phi0.75.csv'):
            # Get the original name without extension
            original_name, ext = os.path.splitext(file)
            # Create the new name
            new_name = f"{original_name[:-8]}{ext}"
            # Rename the file
            try:
                os.rename(file, new_name)
            except FileExistsError:
                print('File already exists.')
            print(f"Renamed: {file} -> {new_name}")
        else:
            print(f"Skipped: {file} already has a code suffix.")


if __name__ == "__main__":
    rename_csv_files()
